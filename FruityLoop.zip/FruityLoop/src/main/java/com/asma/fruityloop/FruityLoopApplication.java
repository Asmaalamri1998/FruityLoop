package com.asma.fruityloop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FruityLoopApplication {

	public static void main(String[] args) {
		SpringApplication.run(FruityLoopApplication.class, args);
	}

}
