package com.asma.fruityloop.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.asma.fruityloop.model.Item;



@Controller
public class ItemController {
	@RequestMapping("/")
	public String item(Model model) {
		
		ArrayList<Item> fruites = new ArrayList<Item>();
		fruites.add(new Item("Kiwi", 1.5));
		fruites.add(new Item("mango", 2.0));
		fruites.add(new Item("gogi berries",4.0));
		fruites.add(new Item("guava", 0.75));
		model.addAttribute("fruites", fruites);
		
		return "index.jsp";
		
		
	
		
		
	
		
	}

}
